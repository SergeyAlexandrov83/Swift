//
//  ProfileView.swift
//  Netology_IB_Instruments
//
//  Created by Сергей Александров on 11.02.2023.
//

import UIKit

class ProfileView: UIView {

    @IBOutlet weak var UserFoto: UIImageView!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Date: UILabel!
    @IBOutlet weak var City: UILabel!
    @IBOutlet weak var Text: UITextView!
    
}
