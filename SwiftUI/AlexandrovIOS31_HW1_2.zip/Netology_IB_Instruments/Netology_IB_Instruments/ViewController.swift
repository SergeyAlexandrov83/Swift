//
//  ViewController.swift
//  Netology_IB_Instruments
//
//  Created by Сергей Александров on 11.02.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

